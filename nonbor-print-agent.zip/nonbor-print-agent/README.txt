==================================================
  NONBOR PRINT AGENT - O'RNATISH YO'RIQNOMASI
==================================================

Bu dastur oshxonadagi printerga buyurtmalarni
avtomatik chop etadi.


1-QADAM: PYTHON O'RNATISH
--------------------------
Agar kompyuterda Python yo'q bo'lsa:

  1. https://www.python.org/downloads/ ga kiring
  2. "Download Python" tugmasini bosing
  3. O'rnatishda "Add Python to PATH" ni ALBATTA belgilang!
  4. Install bosing


2-QADAM: SETUP ISHGA TUSHIRISH
--------------------------------
  1. setup.bat ni ikki marta bosing
  2. Kutubxonalar avtomatik o'rnatiladi
  3. Printerlar ro'yxati ko'rinadi
  4. config.ini ochiladi - sozlamalarni kiriting:

     [server]
     url = https://nonbor.uz/api/v2

     [business]
     id = (admin bergan raqam)

     [auth]
     username = (admin bergan login)
     password = (admin bergan parol)

     [printer]
     default_printer = (ro'yxatdagi printer nomi)

  5. Saqlang va yoping


3-QADAM: ISHGA TUSHIRISH
--------------------------
  start.bat ni ikki marta bosing.

  Agent ishga tushadi va buyurtmalar kutadi.
  Yangi buyurtma kelganda avtomatik chop etadi.

  To'xtatish: Ctrl+C yoki oynani yoping.


4-QADAM (IXTIYORIY): AVTOMATIK ISHGA TUSHIRISH
-------------------------------------------------
Kompyuter yoqilganda agent avtomatik ishlashi uchun:

  1. Win+R bosing
  2. shell:startup yozing, Enter bosing
  3. auto_start.bat faylini shu papkaga nusxalang

  Endi har safar kompyuter yonsa agent ishlaydi.


MUAMMO BO'LSA
--------------
  - "Python topilmadi" - 1-qadamni takrorlang
  - "Serverga ulanib bo'lmadi" - internet va config.ini tekshiring
  - "Printer topilmadi" - config.ini da printer nomini tekshiring
  - agent.log faylida batafsil xatoliklar yoziladi


FAYLLAR
--------
  config.ini       - Sozlamalar
  print_agent.py   - Asosiy dastur
  setup.bat        - Birinchi o'rnatish
  start.bat        - Ishga tushirish
  auto_start.bat   - Avtomatik ishga tushirish
  agent.log        - Xatoliklar jurnali
  README.txt       - Shu fayl


ALOQA
------
  Muammo bo'lsa admin bilan bog'laning.

==================================================
